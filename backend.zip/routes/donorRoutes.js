import express from "express";
import mongoose from "mongoose";

const router = express.Router();

const donorSchema = new mongoose.Schema({
  name: String,
  bloodGroup: String,
  phone: String,
  city: String,
});

const Donor = mongoose.model("Donor", donorSchema);

// Register Donor
router.post("/register", async (req, res) => {
  try {
    const donor = new Donor(req.body);
    await donor.save();
    res.status(201).send("Donor registered");
  } catch (err) {
    res.status(500).send("Error saving donor");
  }
});

// Search Donors
router.get("/search", async (req, res) => {
  const { bloodGroup, city } = req.query;
  try {
    const donors = await Donor.find({ bloodGroup, city });
    res.json(donors);
  } catch (err) {
    res.status(500).send("Error searching donors");
  }
});

// Get All Donors (blood-stock page)
router.get("/all", async (req, res) => {
  try {
    const donors = await Donor.find();
    res.json(donors);
  } catch (err) {
    res.status(500).send("Error fetching data");
  }
});

export default router;
